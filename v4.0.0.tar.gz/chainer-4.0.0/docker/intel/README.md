Chainer with iDeep
==================

Dockerfiles for Chainer accelerated by [iDeep](https://github.com/intel/ideep).
