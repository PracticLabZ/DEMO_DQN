# Recursive Nets for Sentiment Analysis

This example implements the simple recursive model by Richard Socher.
It requires the preprocessed dataset which is available by running `download.py`.
