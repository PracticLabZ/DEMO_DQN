from chainer.training._updater import Updater  # NOQA

# For backward compatibility
from chainer.training.updaters.parallel_updater import ParallelUpdater  # NOQA
from chainer.training.updaters.standard_updater import StandardUpdater  # NOQA
