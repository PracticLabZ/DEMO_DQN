from chainer.training.updaters import multiprocess_parallel_updater  # NOQA
from chainer.training.updaters import parallel_updater  # NOQA
from chainer.training.updaters import standard_updater  # NOQA

from chainer.training.updaters.multiprocess_parallel_updater import MultiprocessParallelUpdater  # NOQA
from chainer.training.updaters.parallel_updater import ParallelUpdater  # NOQA
from chainer.training.updaters.standard_updater import StandardUpdater  # NOQA
