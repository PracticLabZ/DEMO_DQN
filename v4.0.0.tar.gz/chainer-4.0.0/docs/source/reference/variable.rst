Variable and Parameter
----------------------

.. autosummary::
   :toctree: generated/
   :nosignatures:

   chainer.Variable
   chainer.as_variable
   chainer.Parameter
   chainer.variable.VariableNode
