Convolution/Deconvolution utilities
-----------------------------------

.. autosummary::
   :toctree: generated/
   :nosignatures:

   chainer.utils.get_conv_outsize
   chainer.utils.get_deconv_outsize
