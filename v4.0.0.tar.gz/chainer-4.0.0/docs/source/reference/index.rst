*********
Reference
*********

.. module:: chainer

.. toctree::
   :maxdepth: 2

   variable
   functions
   links
   optimizers
   initializers
   training
   datasets
   iterators
   serializers
   util
   configuration
   debug
   graph
   caffe
   check
