Guides
======

.. toctree::
   :maxdepth: 1

   define_by_run
   variables
   links
   functions
   models
   optimizers
   trainer
   extensions
   gpu
   type_checks
   serializers
