
from chainer.graph_optimizations.static_graph_utilities import static_code  # NOQA
