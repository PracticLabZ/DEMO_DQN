class PerformanceWarning(RuntimeWarning):
    """Warning that indicates possible performance issues."""
