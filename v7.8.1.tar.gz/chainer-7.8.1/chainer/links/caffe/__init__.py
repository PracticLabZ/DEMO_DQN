from chainer.links.caffe.caffe_function import CaffeFunction  # NOQA
