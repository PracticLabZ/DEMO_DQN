from chainermn.testing.device import get_device  # NOQA
